# AnalyzerZakup

A parser for obtaining data from the public procurement website
